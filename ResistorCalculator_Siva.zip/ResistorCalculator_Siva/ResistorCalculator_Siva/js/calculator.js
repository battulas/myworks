var multiplier = new Array()
	multiplier[0] = 0
	multiplier[1] = 1
	multiplier[2] = 2
	multiplier[3] = 3
	multiplier[4] = 4
	multiplier[5] = 5
	multiplier[6] = 6
	multiplier[7] = 7
	multiplier[8] = 8
	multiplier[9] = 9
	multiplier[10] = -1
	multiplier[11] = -2

var tolerance = new Array()
	tolerance[0] = "+/-5%"
	tolerance[1] = "+/-10%"
	tolerance[2] = "+/-20%"

function format(ohmage) {
	if (ohmage >= 10e6) {
		ohmage /= 10e5
		return "" + ohmage + " M"
	} else {
		if (ohmage >= 10e3) {
			ohmage /= 10e2
			return "" + ohmage + " K"
		} else {
			return "" + ohmage + " O"
		}
	}
}


function calcOhms() {
	var form = document.forms[0]
	var d1 = form.tensSelect.selectedIndex
	var d2 = form.onesSelect.selectedIndex
	var m = form.multiplierSelect.selectedIndex
	var t = form.toleranceSelect.selectedIndex
	var ohmage = (d1 * 10) + d2
	ohmage = eval("" + ohmage + "e" + multiplier[m])
	ohmage = format(ohmage)
	var tol = tolerance[t]
	document.forms[1].result.value = ohmage + ", " + tol
}
